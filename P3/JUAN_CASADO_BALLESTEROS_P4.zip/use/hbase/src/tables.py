
tables = {
  'Tweets':{
    'name': 'tweets',
    'families': ['t', 'u', 'e', 'p'],
  },
  'Mentions':{
    'name': 'mentions',
    'families': ['f'],
  },
  'Mentiones':{
    'name': 'mentioned',
    'families': ['f'],
  }
}